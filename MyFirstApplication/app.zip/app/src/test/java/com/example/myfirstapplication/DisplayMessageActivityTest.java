package com.example.myfirstapplication;

import static org.junit.Assert.*;

/**
 * Created by jinyu on 10/8/2017.
 */
public class DisplayMessageActivityTest {

}